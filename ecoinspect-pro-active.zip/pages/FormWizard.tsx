
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FORMS } from '../constants';
import { Inspector, BusinessData, InspectionRecord, FormDefinition, ChecklistField } from '../types';

interface FormWizardProps {
  onSave: (record: InspectionRecord) => void;
  inspectors: Inspector[];
  onAddInspector: (inspector: Inspector) => void;
  onDeleteInspector: (id: string) => void;
}

const FormWizard: React.FC<FormWizardProps> = ({ onSave, inspectors, onAddInspector, onDeleteInspector }) => {
  const navigate = useNavigate();
  
  // Mengembalikan ke Step 1 (Mode Normal)
  const [step, setStep] = useState(1);
  const [isSaving, setIsSaving] = useState(false);

  // State awal dikosongkan kembali
  const [selectedInspectorId, setSelectedInspectorId] = useState('');
  const [showAddInspector, setShowAddInspector] = useState(false);
  
  const initialNewInspector = {
    name: '', nip: '', pangkatGol: '', jabatan: '', noPejabat: '', instansi: '', suratTugas: ''
  };
  const [newInspector, setNewInspector] = useState<Omit<Inspector, 'id'>>(initialNewInspector);

  const [business, setBusiness] = useState<BusinessData>({
    name: '', type: '', kbli: '', operatingYear: '', capitalStatus: 'PMDN',
    responsiblePerson: '', responsibleTitle: '', phone: '', address: '',
    coordinates: { latitude: null, longitude: null },
    date: new Date().toISOString().split('T')[0],
    time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
  });
  const [locating, setLocating] = useState(false);

  // Form dikembalikan ke null
  const [selectedForm, setSelectedForm] = useState<FormDefinition | null>(null);
  const [responses, setResponses] = useState<Record<string, any>>({});
  const [notes, setNotes] = useState('');

  // Track extra rows for tables
  const [tableRowCounts, setTableRowCounts] = useState<Record<string, number>>({});

  // Signatures
  const [inspectorSign, setInspectorSign] = useState('');
  const [responsibleSign, setResponsibleSign] = useState('');

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation tidak didukung oleh browser Anda.');
      return;
    }

    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setBusiness(prev => ({
          ...prev,
          coordinates: {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          }
        }));
        setLocating(false);
      },
      (error) => {
        console.error('Error getting location:', error);
        alert('Gagal mengambil lokasi. Pastikan izin lokasi diberikan.');
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
    );
  };

  const handleFinalSave = () => {
    const inspector = inspectors.find(i => i.id === selectedInspectorId);
    if (!inspector || !selectedForm) return;
    setIsSaving(true);
    const record: InspectionRecord = {
      id: Math.random().toString(36).substr(2, 9),
      inspector, business, formId: selectedForm.id, formTitle: selectedForm.title,
      responses, notes, signatures: { inspector: inspectorSign, responsible: responsibleSign },
      createdAt: new Date().toISOString()
    };
    setTimeout(() => { onSave(record); setIsSaving(false); navigate('/history'); }, 1500);
  };

  const addTableRow = (fieldId: string) => {
    setTableRowCounts(prev => ({
      ...prev,
      [fieldId]: (prev[fieldId] || 0) + 1
    }));
  };

  const handleDeleteInspector = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Hapus data pengawas ini?')) {
      onDeleteInspector(id);
      if (selectedInspectorId === id) setSelectedInspectorId('');
    }
  };

  const handleAddInspectorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = Math.random().toString(36).substr(2, 9);
    onAddInspector({ id, ...newInspector });
    setSelectedInspectorId(id);
    setNewInspector(initialNewInspector); 
    setShowAddInspector(false);
  };

  const renderField = (field: ChecklistField) => {
    if (field.type === 'header') {
      return (
        <div key={field.id} className="pt-6 pb-2 border-b-2 border-[#004d40] mb-4">
          <h3 className="text-[12px] font-bold text-[#004d40] uppercase tracking-wider">{field.label}</h3>
        </div>
      );
    }

    if (field.type === 'table' && field.columns) {
      const baseRows = field.rows || [];
      const extraCount = tableRowCounts[field.id] || 0;
      const totalRows = baseRows.length + extraCount;

      return (
        <div key={field.id} className="mb-8 overflow-hidden rounded-lg border border-black shadow-none bg-white">
          <div className="bg-gray-100/50 p-3 border-b border-black">
            <h4 className="font-bold text-gray-800 text-[11px] leading-tight">{field.label}</h4>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px] text-left border-collapse">
              <thead className="bg-white text-gray-800 uppercase font-bold">
                <tr>
                  <th className="px-3 py-2 border-r border-b border-black w-8 text-center bg-gray-50">No</th>
                  {field.columns.map(col => (
                    <th key={col} className="px-3 py-2 border-r border-b border-black text-center bg-gray-50">{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-black">
                {Array.from({ length: totalRows }).map((_, idx) => {
                  const rowLabel = baseRows[idx] || '';
                  return (
                    <tr key={`${field.id}_row_${idx}`} className="h-10">
                      <td className="px-3 py-2 border-r border-black text-center font-bold text-gray-700 bg-gray-50/30">{idx + 1}.</td>
                      {field.columns!.map((col, colIdx) => (
                        <td key={col} className="px-0 py-0 border-r border-black relative">
                          <input 
                            type="text" 
                            placeholder={colIdx === 0 && rowLabel ? rowLabel : "......."}
                            className="w-full h-10 px-3 py-2 bg-transparent border-none outline-none text-[11px] focus:bg-emerald-50/30 text-center"
                            value={responses[`${field.id}_${idx}_${col}`] || (colIdx === 0 && rowLabel ? rowLabel : '')}
                            onChange={e => setResponses({...responses, [`${field.id}_${idx}_${col}`]: e.target.value})}
                          />
                        </td>
                      ))}
                    </tr>
                  );
                })}
                <tr className="bg-gray-50">
                  <td className="px-3 py-2 border-r border-black text-center text-gray-800 font-bold italic">Dst</td>
                  <td colSpan={field.columns.length} className="px-3 py-1">
                    <button 
                      onClick={() => addTableRow(field.id)}
                      className="text-[#004d40] text-[10px] font-bold hover:underline flex items-center gap-1 py-1 uppercase tracking-tight"
                    >
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                      Tambah Baris
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      );
    }

    return (
      <div key={field.id} className="pb-5 mb-5 border-b border-gray-200 last:border-0">
        <label className="block text-gray-900 font-bold mb-3 text-[12px] leading-relaxed">{field.label}</label>
        {field.type === 'boolean' ? (
          <div className="flex gap-3 max-w-sm">
            <button 
              onClick={() => setResponses({...responses, [field.id]: true})} 
              className={`flex-1 py-3 rounded-lg border-2 font-bold text-xs transition-all ${responses[field.id] === true ? 'bg-[#004d40] border-[#004d40] text-white shadow-md' : 'bg-white border-gray-200 text-gray-400 hover:border-emerald-200'}`}
            >
              YA
            </button>
            <button 
              onClick={() => setResponses({...responses, [field.id]: false})} 
              className={`flex-1 py-3 rounded-lg border-2 font-bold text-xs transition-all ${responses[field.id] === false ? 'bg-rose-600 border-rose-600 text-white shadow-md' : 'bg-white border-gray-200 text-gray-400 hover:border-rose-200'}`}
            >
              TIDAK
            </button>
          </div>
        ) : (
          <input 
            type="text" 
            value={responses[field.id] || ''} 
            onChange={e => setResponses({...responses, [field.id]: e.target.value})} 
            className="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:border-[#004d40] focus:ring-2 focus:ring-emerald-50 transition-all bg-white text-[12px] placeholder:text-gray-300 shadow-sm" 
            placeholder="Ketik keterangan lapangan..."
          />
        )}
      </div>
    );
  };

  const steps = [{ id: 1, label: 'Pengawas' }, { id: 2, label: 'Usaha' }, { id: 3, label: 'Form' }, { id: 4, label: 'Check' }, { id: 5, label: 'BA' }];

  return (
    <div className="max-w-3xl mx-auto pb-12 animate-fadeIn print:hidden px-2">
      <div className="mb-8 overflow-x-auto">
        <div className="flex justify-between items-center min-w-[400px] py-2 px-4">
          {steps.map((s, idx) => (
            <React.Fragment key={s.id}>
              <div className="flex flex-col items-center gap-1">
                <button 
                  onClick={() => setStep(s.id)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-all ${step === s.id ? 'bg-[#004d40] border-[#004d40] text-white shadow-lg scale-110' : step > s.id ? 'bg-emerald-600 border-emerald-600 text-white' : 'bg-white border-gray-200 text-gray-300 hover:border-emerald-100'}`}
                >
                  {step > s.id ? '✓' : s.id}
                </button>
                <span className={`text-[8px] font-bold uppercase tracking-widest mt-1 ${step >= s.id ? 'text-[#004d40]' : 'text-gray-300'}`}>{s.label}</span>
              </div>
              {idx < steps.length - 1 && <div className={`flex-1 h-0.5 mx-2 ${step > s.id ? 'bg-emerald-600' : 'bg-gray-100'}`}></div>}
            </React.Fragment>
          ))}
        </div>
      </div>

      {step === 1 && (
        <div className="bg-white rounded-2xl shadow-md p-8 border border-gray-100">
          <h2 className="text-xl font-bold text-gray-800 mb-8 border-b pb-4">Pilih Pejabat Pengawas</h2>
          {!showAddInspector ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {inspectors.map(i => (
                  <div key={i.id} className="relative group">
                    <button 
                      onClick={() => setSelectedInspectorId(i.id)} 
                      className={`w-full p-5 rounded-xl border-2 text-left transition-all ${selectedInspectorId === i.id ? 'border-[#004d40] bg-emerald-50/50 shadow-md' : 'border-gray-100 hover:border-emerald-200 bg-white'}`}
                    >
                      <p className="font-bold text-gray-900 text-[14px] pr-8 mb-1">{i.name}</p>
                      <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wide">NIP: {i.nip}</p>
                      <div className="mt-3 px-2 py-1 bg-white border border-gray-100 rounded text-[9px] text-[#004d40] font-bold uppercase tracking-wider inline-block">
                        {i.jabatan}
                      </div>
                    </button>
                    <button 
                      onClick={(e) => handleDeleteInspector(e, i.id)}
                      className="absolute top-3 right-3 p-1.5 text-gray-300 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100 bg-white rounded-lg shadow-sm"
                      title="Hapus Pengawas"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                ))}
                <button onClick={() => setShowAddInspector(true)} className="p-6 rounded-xl border-2 border-dashed border-gray-200 text-gray-400 hover:text-[#004d40] hover:border-[#004d40] transition-all flex flex-col items-center justify-center gap-2 bg-gray-50/50">
                  <div className="w-10 h-10 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center text-xl font-light">+</div>
                  <span className="font-bold uppercase text-[10px] tracking-widest">Tambah Pengawas</span>
                </button>
              </div>
              <button disabled={!selectedInspectorId} onClick={() => setStep(2)} className="w-full bg-[#004d40] disabled:bg-gray-100 text-white font-bold py-4 rounded-xl shadow-lg mt-8 transition-all text-xs uppercase tracking-widest hover:bg-[#003d33]">Lanjut ke Data Usaha</button>
            </div>
          ) : (
            <form onSubmit={handleAddInspectorSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="md:col-span-2"><label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest">Nama Lengkap & Gelar</label><input required type="text" value={newInspector.name} onChange={e => setNewInspector({...newInspector, name: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 outline-none text-sm focus:border-[#004d40] bg-gray-50/30" /></div>
              <div><label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest">NIP</label><input required type="text" value={newInspector.nip} onChange={e => setNewInspector({...newInspector, nip: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 outline-none text-sm focus:border-[#004d40] bg-gray-50/30" /></div>
              <div><label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest">Pangkat/Gol</label><input required type="text" value={newInspector.pangkatGol} onChange={e => setNewInspector({...newInspector, pangkatGol: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 outline-none text-sm focus:border-[#004d40] bg-gray-50/30" /></div>
              <div><label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest">Jabatan</label><input required type="text" value={newInspector.jabatan} onChange={e => setNewInspector({...newInspector, jabatan: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 outline-none text-sm focus:border-[#004d40] bg-gray-50/30" /></div>
              <div><label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest">Instansi</label><input required type="text" value={newInspector.instansi} onChange={e => setNewInspector({...newInspector, instansi: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 outline-none text-sm focus:border-[#004d40] bg-gray-50/30" /></div>
              <div className="md:col-span-2"><label className="block text-[10px] font-bold text-gray-500 mb-2 uppercase tracking-widest">Nomor Surat Tugas</label><input required type="text" value={newInspector.suratTugas} onChange={e => setNewInspector({...newInspector, suratTugas: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 outline-none text-sm focus:border-[#004d40] bg-gray-50/30" /></div>
              <div className="md:col-span-2 flex gap-4 mt-6"><button type="button" onClick={() => setShowAddInspector(false)} className="flex-1 py-4 border-2 border-gray-100 rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-gray-50">Batal</button><button type="submit" className="flex-1 py-4 bg-[#004d40] text-white rounded-xl font-bold text-[10px] uppercase tracking-widest shadow-lg hover:bg-[#003d33]">Simpan Pengawas</button></div>
            </form>
          )}
        </div>
      )}

      {step === 2 && (
        <div className="bg-white rounded-2xl shadow-md p-8 border border-gray-100">
          <h2 className="text-xl font-bold text-gray-800 mb-8 border-b pb-4">Identitas Penanggung Jawab Usaha</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="md:col-span-2"><label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">Nama Badan Usaha / Kegiatan</label><input type="text" value={business.name} onChange={e => setBusiness({...business, name: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 text-sm outline-none focus:border-[#004d40] bg-gray-50/30" /></div>
            <div><label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">KBLI</label><input type="text" value={business.kbli} onChange={e => setBusiness({...business, kbli: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 text-sm outline-none focus:border-[#004d40] bg-gray-50/30" /></div>
            <div><label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">Tahun Operasi</label><input type="text" value={business.operatingYear} onChange={e => setBusiness({...business, operatingYear: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 text-sm outline-none focus:border-[#004d40] bg-gray-50/30" /></div>
            <div className="md:col-span-2"><label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">Alamat Lokasi Usaha</label><textarea rows={3} value={business.address} onChange={e => setBusiness({...business, address: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 text-sm outline-none focus:border-[#004d40] bg-gray-50/30 resize-none" /></div>
            
            <div className="md:col-span-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">Tagging Lokasi Presisi (GPS)</label>
              <div className="flex gap-3 items-center">
                <button 
                  onClick={handleGetLocation}
                  disabled={locating}
                  className="bg-emerald-50 text-[#004d40] border-2 border-emerald-100 hover:border-[#004d40] px-5 py-3 rounded-xl font-bold text-[10px] transition-all flex items-center justify-center gap-2 uppercase tracking-widest shadow-sm"
                >
                  <svg className={`w-4 h-4 ${locating ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  </svg>
                  {locating ? 'Mengambil GPS...' : business.coordinates.latitude ? 'Perbarui Lokasi' : 'Dapatkan Koordinat'}
                </button>
                {business.coordinates.latitude && (
                  <div className="flex-1 px-4 py-3 bg-gray-100/50 rounded-xl border border-gray-200 text-[11px] font-mono text-gray-600 flex items-center justify-center gap-2">
                    <span className="font-bold text-[#004d40]">LOC:</span>
                    {business.coordinates.latitude.toFixed(7)}, {business.coordinates.longitude?.toFixed(7)}
                  </div>
                )}
              </div>
            </div>

            <div><label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">Penanggung Jawab</label><input type="text" value={business.responsiblePerson} onChange={e => setBusiness({...business, responsiblePerson: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 text-sm outline-none focus:border-[#004d40] bg-gray-50/30" /></div>
            <div><label className="text-[10px] font-bold text-gray-500 uppercase mb-2 block tracking-widest">Jabatan</label><input type="text" value={business.responsibleTitle} onChange={e => setBusiness({...business, responsibleTitle: e.target.value})} className="w-full px-4 py-3 rounded-lg border border-gray-200 text-sm outline-none focus:border-[#004d40] bg-gray-50/30" /></div>
          </div>
          <div className="flex gap-4 mt-10"><button onClick={() => setStep(1)} className="flex-1 py-4 border-2 border-gray-100 rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-gray-50 transition-all">Kembali</button><button onClick={() => setStep(3)} className="flex-1 bg-[#004d40] text-white py-4 rounded-xl font-bold text-[10px] uppercase tracking-widest shadow-lg hover:bg-[#003d33] transition-all">Lanjut Pilih Formulir</button></div>
        </div>
      )}

      {step === 3 && (
        <div className="bg-white rounded-2xl shadow-md p-8 border border-gray-100">
          <h2 className="text-xl font-bold text-gray-800 mb-2">Katalog Formulir Pengawasan</h2>
          <p className="text-gray-400 mb-8 text-[11px] font-bold uppercase tracking-widest">Pilih rincian periksa yang akan digunakan.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {FORMS.map(form => (
              <button key={form.id} onClick={() => { setSelectedForm(form); setStep(4); }} className={`p-5 rounded-2xl border-2 text-left transition-all flex items-start gap-4 ${selectedForm?.id === form.id ? 'border-[#004d40] bg-emerald-50/50 shadow-md' : 'border-gray-50 hover:border-emerald-200 bg-gray-50/30'}`}>
                <div className={`p-3 rounded-xl shadow-sm ${selectedForm?.id === form.id ? 'bg-[#004d40] text-white' : 'bg-white text-[#004d40]'}`}>{form.icon}</div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-bold text-gray-900 text-[14px] leading-tight mb-1">{form.title}</h3>
                  <p className="text-[9px] text-gray-400 uppercase font-bold tracking-widest">{form.subtitle}</p>
                </div>
              </button>
            ))}
          </div>
          <div className="mt-10 flex gap-4"><button onClick={() => setStep(2)} className="flex-1 py-4 border-2 border-gray-100 rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-gray-50">Kembali</button><button disabled={!selectedForm} onClick={() => setStep(5)} className="flex-1 bg-[#004d40] text-white font-bold py-4 rounded-xl shadow-lg uppercase text-[10px] tracking-widest hover:bg-[#003d33]">Lanjut ke Pengesahan</button></div>
        </div>
      )}

      {step === 4 && selectedForm && (
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 animate-slideIn">
          <div className="bg-[#004d40] p-6 text-white flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold tracking-tight">{selectedForm.title}</h2>
              <p className="text-emerald-100 text-[9px] font-bold uppercase tracking-[0.2em] mt-1">Checklist Verifikasi Lapangan Digital</p>
            </div>
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/10 shadow-inner">{selectedForm.icon}</div>
          </div>
          <div className="p-8">
            <div className="mb-6 px-4 py-3 bg-gray-50 rounded-xl border-l-4 border-[#004d40]">
              <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Objek Pengawasan:</p>
              <p className="text-[13px] font-bold text-gray-800">{business.name || 'Pilih/Isi Data Usaha'}</p>
            </div>
            <div className="space-y-2">
              {selectedForm.fields.map(field => renderField(field))}
            </div>
            <div className="mt-10 pt-8 border-t-2 border-gray-100">
              <label className="block text-gray-900 font-bold mb-4 text-[12px] uppercase tracking-widest">Hasil Evaluasi & Kesimpulan Akhir</label>
              <textarea rows={4} value={notes} onChange={e => setNotes(e.target.value)} className="w-full px-5 py-4 rounded-2xl border border-gray-200 focus:border-[#004d40] focus:ring-4 focus:ring-emerald-50 outline-none transition-all bg-white text-[12px] shadow-sm resize-none" placeholder="Tuliskan temuan lapangan, saran, dan catatan penting lainnya di sini..." />
            </div>
            <div className="flex gap-4 mt-12">
              <button onClick={() => setStep(3)} className="flex-1 py-4 border-2 border-gray-100 rounded-2xl font-bold text-[10px] uppercase tracking-widest hover:bg-gray-50 transition-all">Ganti Formulir</button>
              <button onClick={() => setStep(5)} className="flex-[2] bg-[#004d40] text-white font-bold py-4 rounded-2xl shadow-xl transition-all uppercase text-[10px] tracking-widest hover:bg-[#003d33] hover:translate-y-[-2px] active:translate-y-0">Selesai & Lanjut Pengesahan</button>
            </div>
          </div>
        </div>
      )}

      {step === 5 && (
        <div className="bg-white rounded-2xl shadow-md p-8 border border-gray-100 text-center">
          <h2 className="text-xl font-bold text-gray-800 mb-2">Penandatanganan Berita Acara</h2>
          <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mb-12">Konfirmasi keabsahan data lapangan</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-6">
              <div className="px-4 py-2 bg-emerald-50 text-[#004d40] rounded-lg inline-block text-[9px] font-bold uppercase tracking-wider mb-2">Pihak I - Pengawas</div>
              <div className="relative h-40 group">
                <input type="text" placeholder="Tanda Tangan Digital (Nama)" className="w-full h-full px-6 text-center text-3xl font-['Dancing_Script',cursive] italic bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 outline-none focus:border-[#004d40] focus:bg-white transition-all shadow-inner" value={inspectorSign} onChange={e => setInspectorSign(e.target.value)} />
                {!inspectorSign && <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-gray-300 text-[10px] font-bold uppercase tracking-widest">Ketuk untuk TTD</div>}
              </div>
              <p className="font-bold text-gray-900 text-sm border-t pt-3 inline-block px-4">{inspectors.find(i => i.id === selectedInspectorId)?.name || "NAMA PENGAWAS"}</p>
            </div>
            <div className="space-y-6">
              <div className="px-4 py-2 bg-emerald-50 text-[#004d40] rounded-lg inline-block text-[9px] font-bold uppercase tracking-wider mb-2">Pihak II - Penanggung Jawab</div>
              <div className="relative h-40 group">
                <input type="text" placeholder="Tanda Tangan Digital (Nama)" className="w-full h-full px-6 text-center text-3xl font-['Dancing_Script',cursive] italic bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 outline-none focus:border-[#004d40] focus:bg-white transition-all shadow-inner" value={responsibleSign} onChange={e => setResponsibleSign(e.target.value)} />
                {!responsibleSign && <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-gray-300 text-[10px] font-bold uppercase tracking-widest">Ketuk untuk TTD</div>}
              </div>
              <p className="font-bold text-gray-900 text-sm border-t pt-3 inline-block px-4">{business.responsiblePerson || "PENANGGUNG JAWAB"}</p>
            </div>
          </div>
          <div className="mt-16 flex gap-4">
            <button onClick={() => setStep(4)} className="flex-1 py-4 border-2 border-gray-100 rounded-2xl font-bold uppercase text-[10px] tracking-widest hover:bg-gray-50">Kembali ke Data</button>
            <button onClick={handleFinalSave} disabled={!inspectorSign || !responsibleSign || isSaving} className="flex-[2] bg-emerald-600 text-white font-bold py-4 rounded-2xl shadow-xl flex items-center justify-center gap-3 uppercase text-[10px] tracking-widest hover:bg-emerald-700 disabled:bg-gray-200 disabled:shadow-none transition-all">
              {isSaving ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                  Menyimpan Data...
                </>
              ) : "Sahkan Berita Acara (BA)"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default FormWizard;

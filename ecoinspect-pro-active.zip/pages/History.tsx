
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { InspectionRecord } from '../types';
import { FORMS } from '../constants';

interface HistoryProps { records: InspectionRecord[]; }

const History: React.FC<HistoryProps> = ({ records }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeRecord, setActiveRecord] = useState<InspectionRecord | null>(null);

  const filteredRecords = records.filter(r => 
    r.business.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    r.inspector.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handlePrint = (record: InspectionRecord) => {
    setActiveRecord(record);
    setTimeout(() => { window.print(); setActiveRecord(null); }, 300);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn px-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <button onClick={() => navigate('/')} className="text-[#004d40] hover:text-[#00695c] flex items-center gap-2 font-bold uppercase text-[10px] tracking-widest">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg> Dashboard
        </button>
        <h2 className="text-2xl font-bold text-gray-800">Arsip Pengawasan</h2>
      </div>

      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 print:hidden">
        <div className="relative">
          <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input type="text" placeholder="Cari nama perusahaan atau pejabat..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-11 pr-4 py-4 rounded-xl bg-gray-50 outline-none focus:ring-2 focus:ring-[#004d40] transition-all" />
        </div>
      </div>

      <div className="space-y-4 print:hidden">
        {filteredRecords.length > 0 ? filteredRecords.map((record) => (
          <div key={record.id} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6 hover:shadow-md transition-all">
            <div className="flex-1 text-center md:text-left">
              <div className="flex items-center gap-2 mb-2 justify-center md:justify-start">
                <span className="text-[9px] font-bold bg-[#e0f2f1] text-[#004d40] px-3 py-1 rounded-full uppercase tracking-widest">Form {record.formId}</span>
                <span className="text-xs text-gray-400 font-medium">{new Date(record.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
              </div>
              <h3 className="text-xl font-bold text-gray-800 tracking-tight">{record.business.name}</h3>
              <p className="text-sm text-gray-500 mt-1">Oleh: <span className="font-semibold">{record.inspector.name}</span></p>
            </div>
            <button onClick={() => handlePrint(record)} className="bg-[#004d40] hover:bg-[#003d33] text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-emerald-50 flex items-center gap-2 transition-all transform active:scale-95 text-xs uppercase tracking-widest">
              Unduh BA
            </button>
          </div>
        )) : (
          <div className="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-gray-100">
            <p className="text-gray-400 font-medium">Belum ada data pengawasan yang tersimpan.</p>
          </div>
        )}
      </div>

      {activeRecord && (
        <div className="hidden print:block bg-white text-black p-12 font-serif leading-tight" id="printable-ba">
          <div className="text-center mb-8 border-b-2 border-black pb-4 uppercase">
            <p className="text-[10px] font-sans">LAMPIRAN IV PERATURAN MENTERI LINGKUNGAN HIDUP DAN KEHUTANAN REPUBLIK INDONESIA</p>
            <p className="text-[10px] font-sans">NOMOR 14 TAHUN 2024</p>
            <p className="text-[10px] font-sans mt-2 italic font-bold">Format Berita Acara Pengawasan Lingkungan Hidup</p>
          </div>

          <div className="text-center font-bold mb-10">
            <p className="text-xl underline">BERITA ACARA</p>
            <p className="text-xl">PENGAWASAN LINGKUNGAN HIDUP</p>
          </div>

          <p className="mb-8 text-base text-justify leading-relaxed">
            Pada hari ini, tanggal {new Date(activeRecord.business.date).getDate()} bulan {new Intl.DateTimeFormat('id-ID', { month: 'long' }).format(new Date(activeRecord.business.date))} tahun {new Date(activeRecord.business.date).getFullYear()}, 
            telah dilakukan pengawasan terhadap PT {activeRecord.business.name} yang berlokasi di {activeRecord.business.address} dengan rincian hasil pengawasan sebagai berikut:
          </p>

          <div className="mb-8">
            <p className="font-bold text-base mb-3">A. IDENTITAS PENGAWAS & USAHA</p>
            <table className="w-full text-sm mt-2 border-collapse">
              <tbody>
                <tr><td className="w-64 font-bold border border-black p-2">Nama Pengawas</td><td className="border border-black p-2">{activeRecord.inspector.name}</td></tr>
                <tr><td className="font-bold border border-black p-2">Nomor Induk Pegawai (NIP)</td><td className="border border-black p-2">{activeRecord.inspector.nip}</td></tr>
                <tr><td className="font-bold border border-black p-2">Nama Perusahaan</td><td className="border border-black p-2">PT. {activeRecord.business.name}</td></tr>
                <tr><td className="font-bold border border-black p-2">Bidang Usaha / KBLI</td><td className="border border-black p-2">{activeRecord.business.kbli}</td></tr>
                <tr>
                  <td className="font-bold border border-black p-2">Koordinat Lokasi</td>
                  <td className="border border-black p-2">
                    {activeRecord.business.coordinates.latitude ? 
                      `${activeRecord.business.coordinates.latitude}, ${activeRecord.business.coordinates.longitude}` : 
                      'Tidak tercatat'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mb-8">
            <p className="font-bold text-base uppercase mb-4">B. DAFTAR RINCIAN PERIKSA PENGAWASAN (FORM {activeRecord.formId})</p>
            <table className="w-full text-[11px] border-collapse border border-black">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-black p-2 w-12 text-center">NO</th>
                  <th className="border border-black p-2">KETENTUAN / ASPEK PEMERIKSAAN</th>
                  <th className="border border-black p-2 w-12 text-center">YA</th>
                  <th className="border border-black p-2 w-12 text-center">TDK</th>
                  <th className="border border-black p-2">KETERANGAN LAPANGAN</th>
                </tr>
              </thead>
              <tbody>
                {FORMS.find(f => f.id === activeRecord.formId)?.fields.map((field, idx) => {
                  if (field.type === 'header') return <tr key={field.id} className="bg-gray-50 font-bold"><td colSpan={5} className="border border-black p-2 uppercase italic">{field.label}</td></tr>;
                  if (field.type === 'table') return null; 
                  const res = activeRecord.responses[field.id];
                  return (
                    <tr key={field.id}>
                      <td className="border border-black p-2 text-center font-bold">{idx + 1}</td>
                      <td className="border border-black p-2">{field.label}</td>
                      <td className="border border-black p-2 text-center font-bold">{res === true ? 'X' : ''}</td>
                      <td className="border border-black p-2 text-center font-bold">{res === false ? 'X' : ''}</td>
                      <td className="border border-black p-2 text-gray-600 italic">{typeof res === 'string' ? res : ''}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="mt-6 p-4 border-2 border-black italic text-sm leading-relaxed bg-gray-50/30">
            <p className="font-bold not-italic underline mb-2 uppercase">EVALUASI AKHIR / TEMUAN PENGAWAS:</p>
            {activeRecord.notes || "Pengawasan telah dilaksanakan sesuai dengan prosedur. Seluruh aspek yang diperiksa telah terdokumentasi dengan baik sesuai fakta lapangan."}
          </div>

          <div className="mt-20 flex justify-between px-16 text-sm">
            <div className="text-center w-64">
              <p className="mb-20 font-bold">Pejabat Pengawas,</p>
              <p className="font-bold underline uppercase">{activeRecord.inspector.name}</p>
              <p className="text-[10px] font-sans mt-2 opacity-60">Verified Digital Identity</p>
            </div>
            <div className="text-center w-64">
              <p className="mb-20 font-bold">Penanggung Jawab Usaha,</p>
              <p className="font-bold underline uppercase">{activeRecord.business.responsiblePerson || "Penanggung Jawab"}</p>
              <p className="text-[10px] font-sans mt-2 opacity-60">Verified Digital Identity</p>
            </div>
          </div>

          <div className="mt-24 text-center text-[9px] font-sans border-t pt-4 border-black opacity-40">
            Diterbitkan secara elektronik oleh EcoInspect Pro sesuai PERMENLHK NO 14 TAHUN 2024. Dokumen ini sah dan memiliki kekuatan hukum yang tetap.
          </div>
        </div>
      )}
    </div>
  );
};

export default History;
